import os, django
os.environ['DJANGO_SETTINGS_MODULE'] = os.getcwd().split("\\")[-1]+".settings"
django.setup()
from onlineapp.models import *
import click
import MySQLdb
from openpyxl import load_workbook
from onlineapp.models import *


USERNAME = "root"
PASSWORD =""
HOST ="localhost"
DBNAME="django1"

file1 = "students.xlsx"
file2 = "results.xlsx"

def already_exists(dbname):
    conn = MySQLdb.connect(HOST, USERNAME, PASSWORD)
    c = conn.cursor()
    return True if c.execute("SHOW DATABASES LIKE '%s';"%(dbname)) else False

def get_required_sheet(file,sheet):
    try:
        wb=load_workbook(file)
    except:
        click.echo("Reacheck the file names!")
    if sheet in wb.sheetnames:
        return wb[sheet]
    return None
def getValue(sheet,row,col):
    value=sheet.cell(row=row,column=col).value
    try:
        return int(value)
    except:
        return value
    # return int(value) if value.strip().isdigit() else value

@click.group()
@click.pass_context
def cli(ctx):
    pass

# importdata students.xlsx
# importdata results.xlsx
# importdata final.xlsx
@cli.command(help='import excel files into MYSQL database')
@click.argument("tokens", nargs=-1)
@click.pass_context
def importdata(ctx, tokens):

    if(tokens[0] == "college"):
        sheet = get_required_sheet(file1, 'Colleges')
        for row in range(2, sheet.max_row + 1):
            c = College(name=getValue(sheet, row, 1), location=getValue(sheet, row, 3), acronym=getValue(sheet, row, 2),
                        contact=getValue(sheet, row, 4))
            c.save()
        click.echo('college data inserted')
    elif(tokens[0] == "student"):
        sheet = get_required_sheet(file1, "Current")
        # sheet2 = get_required_sheet(file1, "Colleges")

        for row in range(2, sheet.max_row + 1):
            # print(College.objects.get(acronym=getValue(sheet, row, 2)))
            c = Student(name=getValue(sheet, row, 1), college=College.objects.get(acronym=getValue(sheet, row, 2)),
                        email=getValue(sheet, row, 3), db_folder=getValue(sheet, row, 4).lower())
            c.save()
    # Student.objects.get(db_folder__contains=)
        click.echo("student data inserted")
    elif(tokens[0] == "mocktest"):
        sheet = get_required_sheet(file2, 'results')
        for row in range(2, sheet.max_row + 1):
            # print(Student.objects.get(db_folder=getValue(sheet, row, 1).split('_')[-2]))
            c = Mocktest(student=Student.objects.get(db_folder=getValue(sheet, row, 1).split('_')[-2]),
                          problem1=getValue(sheet, row, 2), problem2=getValue(sheet, row, 3),
                          problem3=getValue(sheet, row, 4), problem4=getValue(sheet, row, 5), totals=getValue(sheet, row, 6))
            c.save()
        click.echo("marks data inserted")
    else:
        click.echo("Wrong argument given")
    # write_into_tables(tokens)

# command
# create database dbname;
@cli.command(help='creates a database with given name')
@click.argument("name", nargs=1)
@click.pass_context
def createdb(ctx, name):
    if not already_exists(name):
        conn = MySQLdb.connect(HOST,USERNAME,PASSWORD)
        cursor = conn.cursor()
        query = 'create database '+ name + ';'
        cursor.execute(query)
        cursor.close()
        cursor = conn.cursor()
        cursor.execute('use database %s;'%name)
        cursor.close()
        conn.commit()
        conn.close()

# drop database dbname;
@cli.command(help='delete the named database')
@click.argument("name", nargs=1)
@click.pass_context
def dropdb(ctx, name):
    conn = MySQLdb.connect(HOST, USERNAME, PASSWORD)
    cursor = conn.cursor()
    query = 'drop database '+ name + ';'
    cursor.execute(query)
    cursor.close()
    conn.commit()
    conn.close()

if __name__ == '__main__':
    cli(obj={})
    # manager = College.objects.all()
    # querysets = College.objects.all()
    # print(querysets)
