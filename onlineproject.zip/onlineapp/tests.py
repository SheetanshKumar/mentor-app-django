from django.test import TestCase
from onlineapp.models import *
# Create your tests here.
from onlineapp.serializer import CollegeSerializer


class CollegeTestCase(TestCase):
    def setUp(self):
        College.objects.create(name = 'new', location = 'new', acronym = 'new', contact = 'new')

    def test_college(self):
        self.assertEquals(CollegeSerializer(College.objects.get(id=1)).data,{
            'name':'new','location':'new','acronym':'new', 'contact':'new'})
