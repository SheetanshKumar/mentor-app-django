import threading
import requests
import time
from json2html import *
# def f(id):
#     print('thread function %s' %(id))
#     time.sleep(2)
#     return
#
# if __name__ == '__main__':
#     for i in range(500):
#         t = threading.Thread(target=f, args=(i,))
#         t.start()

def get_Student(id):
    try:
        # time.sleep(1)
        student = requests.get(url ='http://www.bhageerathreddy.com/mrnd-hackathon/2018/api/students?page=25')
        print(student.json())
        output = json2html.convert(json=student.json())

        file = open("output.html", "w")
        file.write(output)
        file.close()
    except Exception as e:
        print("Error:", id,e)

if __name__ == '__main__':
    # student = requests.get(url='http://127.0.0.1:8000/api/v1/1/students/5/')
    # print(student)
    for i in range(1):
        t = threading.Thread(target=get_Student, args=(i,))
        t.start()
        t.join()