from django.conf.urls import url
from django.contrib import admin
from django.urls import path
from onlineapp.views import *
from onlineapp import *
urlpatterns = [
    # url(r'counter/', views.session_counter),
    # url(r'college/', views.func_view),
    # url(r'college/<str:acronym>', views.college_students_list),
    # url(r'students_details/', views.func_view2),
    # url(r'students_details/<int:id>/', views.get_student_by_id),
    # url(r'test_exception/', views.test_exception)

    # path('counter/', CollegeView.as_view(), name = ""),
    path('college/', CollegeView.as_view(), name = "college"),
    # path('students_details/', CreateStudentView.as_view(), name = "students"),
    path('college/<str:acronym>/', CollegeResults.as_view(), name = "students"),
    path('add_college/', CreateCollegeView.as_view(), name = ""),
    path('college/<str:acronym>/add_student/', CreateStudentView.as_view(), name = ""),
    path('college/<str:acronym>/<int:pk>/confirm_delete/', DeleteStudent.as_view(), name = ""),
    path('<int:pk>/confirm_delete/', DeleteCollege.as_view(), name = ""),
    path('sign_up/', SignupView.as_view(),name = 'signup'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView, name = 'logout'),
    path('api/v1/', CollegeApiView.as_view(), name = 'all_api'),
    path('api/v1/<int:pk>/', CollegeApiSingleView.as_view(), name = 'single_api'),
    path('api/v1/students/', StudentApiView.as_view(), name='student_all'),
    path('api/v1/<int:pk>/students/', StudentApiView.as_view(), name='student_all'),
    path('api/v1/<int:pk>/students/<int:spk>/', StudentApiView.as_view(), name='student_single_api')
    # path('students_details/', views.func_view2),
    # path('students_details/<int:id>/', views.get_student_by_id),
    # path('test_exception/', views.test_exception)
]