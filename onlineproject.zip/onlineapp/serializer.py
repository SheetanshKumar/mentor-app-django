from rest_framework import serializers, viewsets
from onlineapp.models import College, Student, Mocktest


class CollegeSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=128)
    location = serializers.CharField(max_length=64)
    acronym = serializers.CharField(max_length=8)
    contact = serializers.EmailField()

    def create(self, validated_data):
        """
        Create and return a new `Snippet` instance, given the validated data.
        """
        return College.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Update and return an existing `Snippet` instance, given the validated data.
        """
        instance.name = validated_data.get('name', instance.name)
        instance.location = validated_data.get('location', instance.location)
        instance.acronym = validated_data.get('acronym', instance.acronym)
        instance.contact = validated_data.get('contact', instance.contact)
        instance.save()
        return instance

class StudentSerializer(serializers.ModelSerializer):
    # college = CollegeSerializer(read_only=True)
    class Meta:
        model = Student
        fields = ['name', 'dob','email','db_folder', 'dropped_out', 'college']

class StudentDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ['name', 'dob', 'email', 'db_folder', 'dropped_out', 'college']

    def update(self, instance, validated_data):
        instance.name = validated_data.get('name', instance.name)
        instance.dob = validated_data.get('dob', instance.dob)
        instance.email = validated_data.get('email', instance.email)
        instance.db_folder = validated_data.get('db_folder', instance.db_folder)
        instance.dropped_out = validated_data.get('dropped_out', instance.dropped_out)
        instance.college = validated_data.get('college', instance.college)
        instance.save()
        return instance

class MocktestSerializer(serializers.Serializer):
    student = StudentSerializer(read_only=True)

    class Meta:
        model = Mocktest
        fields = ['problem1', 'problem2', 'problem3', 'problem4', 'totals', 'student']