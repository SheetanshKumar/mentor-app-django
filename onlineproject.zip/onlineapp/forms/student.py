from django import forms
from onlineapp.models import *

class AddStudent(forms.ModelForm):
    class Meta:
        model = Student
        exclude = ['id','dob','college']
        widgets = {
            'name' : forms.TextInput(attrs={'class' : 'form-control', 'placeholder' : 'Enter Student Name:'}),
            'db_folder': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter Student db_name:'}),
            'email': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Student email:'}),
            'dropped_out': forms.CheckboxInput(attrs={'class': 'form-check-input', 'placeholder': 'Select for dropped_out:'}),
        }

