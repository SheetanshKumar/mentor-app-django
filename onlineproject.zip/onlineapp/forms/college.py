from django import forms
from onlineapp.models import *


class AddCollege(forms.ModelForm):
    class Meta:
        model = College
        exclude = ['id']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter COllege Name:'}),
            'location': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter College Name:'}),
            'acronym': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter College Acronym:'}),
            'contact': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter Contact:'})
        }

