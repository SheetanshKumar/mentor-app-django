from .college import *
from .auth import *
from .mocktest import *
from .student import *