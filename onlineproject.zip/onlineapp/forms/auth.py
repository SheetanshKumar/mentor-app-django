from django import forms

class SignupForm(forms.Form):
    first_name = forms.CharField(
        max_length=75,
        widget= forms.TextInput(attrs={'class' :'form-control', 'placeholder': 'Enter your name'}),
        required=True
    )
    last_name = forms.CharField(
        max_length=75,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter last name'}),
        required=True
    )
    username = forms.CharField(
        max_length=75,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter username'}),
        required=True
    )
    password = forms.CharField(
        max_length=75,
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter password'}),
        required=True
    )
class LoginForm(forms.Form):
    username = forms.CharField(
        max_length=75,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter username'}),
        required=True
    )
    password = forms.CharField(
        max_length=75,
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter password'}),
        required=True
    )