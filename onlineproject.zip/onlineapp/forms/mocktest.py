from django import forms
from onlineapp.models import *


class AddMockTest(forms.ModelForm):
    class Meta:
        model = Mocktest
        exclude = ['id','totals', 'student']
        widgets = {
            'problem1' : forms.NumberInput(),
            'problem2': forms.NumberInput(),
            'problem3': forms.NumberInput(),
            'problem4': forms.NumberInput()
        }
