from django.apps import AppConfig


class OnlineappConfig(AppConfig):
    name = 'onlineapp'
