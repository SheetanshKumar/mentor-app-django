from django.urls import reverse_lazy
from django.views import View
from django.shortcuts import get_object_or_404
from django.views.generic import ListView, DetailView, CreateView, DeleteView
from rest_framework.response import Response
from rest_framework.views import APIView

from onlineapp.forms.college import AddCollege
from onlineapp.models import *
from django.shortcuts import render

from onlineapp.serializer import CollegeSerializer


class CollegeView(View):
    def get(self, request, *args, **kwargs):
        colleges = College.objects.all()
        # ipdb.set_trace()
        return render(
            request,
            template_name='template.html',
            context={
                'colleges_list': colleges
            }
        )

    # def get_colleges(request):
    #     clgs = College.objects.values('name', 'acronym')
    #     template = loader.get_template('colleges.html')
    #     context = dict()
    #     context['colleges_list'] = clgs
    #     return HttpResponse(template.render(context, request))
    #
    # def get_college_students(request, acronym):
    #     students = College.objects.filter(acronym=acronym).values('student__name',
    #                                                               'student__mocktest__totals').order_by(
    #         '-student__mocktest__totals')
    #     template = loader.get_template('students_result.html')
    #     context = dict()
    #     context['students_list'] = students
    #     return HttpResponse(template.render(context, request))


class CollegeResults(DetailView):
    model = Mocktest
    college_object_name = 'student_list'
    template_name = "template2.html"

    def get_object(self, queryset=None):
        return get_object_or_404(College, **self.kwargs)

    def get_context_data(self, **kwargs):
        context = super(CollegeResults, self).get_context_data(**kwargs)

        college = context.get('object')
        # import ipdb
        # ipdb.set_trace()
        students = self.model.objects.values('student__id', 'student__name', 'student__college__acronym', 'totals').order_by('totals').filter(student__college__acronym = college.acronym)
        context.update({self.college_object_name: students})
        return context


class CreateCollegeView(CreateView):
    model = College
    form_class = AddCollege
    template_name = "college_form.html"
    success_url = reverse_lazy('college')


class DeleteCollege(DeleteView):
    model = College
    template_name = 'confirm_delete.html'
    success_url = reverse_lazy('college')

class CollegeApiView(APIView):
    def get(self, request, **kwargs):
        try:
            # college = College.objects.get(id=self.kwargs['pk'])
            college = [CollegeSerializer(user).data for user in College.objects.all()]
        except:
            college = None

        return Response(college, status=404)

    def post(self, request, **kwargs):
        serializer = CollegeSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

class CollegeApiSingleView(APIView):
    def get(self, request, **kwargs):
        try:
            college = College.objects.get(id=self.kwargs['pk'])
            college = CollegeSerializer(college).data
            return Response(data=college, status=200)
        except:
            return Response(data="College not Found!", status=404)

    def put(self, request, **kwargs):
        try:
            college = College.objects.get(id=self.kwargs['pk'])
            college = CollegeSerializer(college,data = request.data)
            if college.is_valid():
                college.save()
                return Response(college.data, status=200)
        except:
            return Response(data="College not Found!", status=404)
    def delete(self, request, **kwargs):
        try:
            college = College.objects.get(id=self.kwargs['pk'])
            college.delete()
            return Response(status=204)
        except:
            return Response(data="College not Found!", status=404)