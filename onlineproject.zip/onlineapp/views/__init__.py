from .college import *
from .student import *
from .auth import *