from django.urls import reverse_lazy
from django.views import View
from django.shortcuts import get_object_or_404, redirect
from django.views.generic import ListView, DetailView, CreateView, DeleteView
from rest_framework.response import Response
from rest_framework.views import APIView

from onlineapp.forms.student import *
from onlineapp.models import *
from django.shortcuts import render

from onlineapp.serializer import StudentSerializer
from onlineapp.templates import *
from onlineapp.forms.student import *
from onlineapp.forms.mocktest import *
from onlineapp.forms.college import *

class CreateStudentView(CreateView):
    model = Student
    form_class = AddStudent
    template_name = "student_form.html"


    def get_context_data(self, **kwargs):
        context = super(CreateStudentView,self).get_context_data(**kwargs)
        student_form = context.get('form')
        mocktest_form = AddMockTest()

        context.update({
            'student':student_form,
            'mocktest':mocktest_form,
        })

        return context

    def post(self, request, *args, **kwargs):
        college = get_object_or_404(College,**kwargs)
        student_form = AddStudent(request.POST)
        mocktest_form = AddMockTest(request.POST)

        if student_form.is_valid():
            student = student_form.save(commit=False)
            student.college = college
            student.save()

            if mocktest_form.is_valid():
                mocktest = mocktest_form.save(commit=False)
                mocktest.totals = sum(mocktest_form.cleaned_data.values())
                mocktest.student = student
                mocktest.save()
            return redirect('students',college.acronym)

class DeleteStudent(DeleteView):
    model = Student
    template_name = "confirm_delete.html"

    def post(self, request, *args, **kwargs):
        student = self.model.objects.get(id=kwargs['pk'])
        student.delete()
        return redirect('college')

class StudentApiView(APIView):
    def get(self, request, **kwargs):
        try:
            if 'spk' in kwargs.keys():
                students = StudentSerializer(Student.objects.get(id=kwargs['spk'])).data
            elif 'pk' in kwargs.keys():
                college = College.objects.get(id=kwargs['pk'])
                students = [StudentSerializer(student).data for student in
                            Student.objects.filter(college=college)]
            else:
                students = [StudentSerializer(student).data for student in
                            Student.objects.all()]
        except:
            students = None
        return Response(students, status=200)
