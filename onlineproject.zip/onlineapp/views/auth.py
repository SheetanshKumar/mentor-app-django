from django.contrib.auth import authenticate, logout, login
from django.http import HttpResponse
from django.views import View
from django.shortcuts import render, redirect
from onlineapp.forms import SignupForm, LoginForm
from django.contrib.auth.models import User

class SignupView(View):
    def get(self, request):
        signup_form = SignupForm()
        return render(
            request,
            template_name = "sign_up.html",
            context={'form':signup_form},
        )
    def post(self, request):
        form = SignupForm(request.POST)
        if form.is_valid():
            if authenticate(
                request,
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password']):
                return HttpResponse("User Already Exists")
            # import ipdb
            # ipdb.set_trace()
            User.objects.create_user(**form.cleaned_data)
            #User.objects.create_user(firstname= form.cleaned_data['firstname'],lastname= form.cleaned_data['lastname'],username=form.cleaned_data['username'],password=form.cleaned_data['password'])

            user = authenticate(
                request,
                username= form.cleaned_data['username'],
                password = form.cleaned_data['password']
            )
            if user is not None:
                return redirect('college')

class LoginView(View):
    def get(self, request):
        login_form = LoginForm()

        return render(
            request,
            template_name='login.html',
            context = {'form': login_form, 'title' : 'login'},
        )
    def post(self, request):
        login_form = LoginForm(request.POST)
        if login_form.is_valid():
            user = authenticate(
                request,
                username=login_form.cleaned_data['username'],
                password=login_form.cleaned_data['password']
            )
            if user:
                login(request, user)
                return redirect('college')
            else:
                HttpResponse('Login Failed')
def LogoutView(request):
    logout(request)
    return redirect('login')
