import requests

students = requests.get("http://127.0.0.1:8000/api/v1/1/students/5/")
print(students.json())